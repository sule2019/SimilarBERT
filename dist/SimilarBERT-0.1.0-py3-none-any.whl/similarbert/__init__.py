from similarbert import SimilarBERT  

__all__ = [
    'SimilarBERT',
]


